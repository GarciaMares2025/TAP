package org.example.parcial2.repository;

import org.example.parcial2.models.Cancion;
import org.example.parcial2.utils.Database;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CancionRepository implements Repository<Cancion> {

    @Override
    public Cancion buscarPorId(int idCancion) {
        String sql = "SELECT * FROM Cancion WHERE idCancion = ?";
        try (Connection conn = Database.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idCancion);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapRowToCancion(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Cancion> buscarTodos() {
        List<Cancion> lista = new ArrayList<>();
        String sql = "SELECT * FROM Cancion";
        try (Connection conn = Database.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(mapRowToCancion(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    @Override
    public void guardar(Cancion c) {
        String sql = "INSERT INTO Cancion (titulo, duracion, idGenero) VALUES (?, ?, ?)";
        try (Connection conn = Database.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, c.getTitulo());
            stmt.setTime(2, c.getDuracion());
            stmt.setInt(3, c.getIdGenero());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actualizar(Cancion c) {
        String sql = "UPDATE Cancion SET titulo = ?, duracion = ?, idGenero = ? WHERE idCancion = ?";
        try (Connection conn = Database.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, c.getTitulo());
            stmt.setTime(2, c.getDuracion());
            stmt.setInt(3, c.getIdGenero());
            stmt.setInt(4, c.getIdCancion());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int idCancion) {
        String sql = "DELETE FROM Cancion WHERE idCancion = ?";
        try (Connection conn = Database.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idCancion);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ---------------------------------------------------
    // Método utilitario para mapear un ResultSet a Cancion
    // ---------------------------------------------------
    private Cancion mapRowToCancion(ResultSet rs) throws SQLException {
        return new Cancion(
                rs.getInt("idCancion"),
                rs.getString("titulo"),
                rs.getTime("duracion"),
                rs.getInt("idGenero")
        );
    }
}
