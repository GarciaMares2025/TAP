package org.example.parcial2.models;

import java.sql.Time;

public class Cancion {
    private int idCancion;
    private String titulo;
    private Time duracion;
    private int idGenero;

    public Cancion() {}

    public Cancion(int idCancion, String titulo, Time duracion, int idGenero) {
        this.idCancion = idCancion;
        this.titulo = titulo;
        this.duracion = duracion;
        this.idGenero = idGenero;
    }

    public int getIdCancion() { return idCancion; }
    public void setIdCancion(int idCancion) { this.idCancion = idCancion; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public Time getDuracion() { return duracion; }
    public void setDuracion(Time duracion) { this.duracion = duracion; }

    public int getIdGenero() { return idGenero; }
    public void setIdGenero(int idGenero) { this.idGenero = idGenero; }
}
