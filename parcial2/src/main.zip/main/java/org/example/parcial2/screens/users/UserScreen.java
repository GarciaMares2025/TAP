package org.example.parcial2.screens.users;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.parcial2.screens.LoginScreen;

public class UserScreen {

    private final Stage stage;
    private final int userId; // ID del usuario autenticado

    public UserScreen(Stage stage, int userId) {
        this.stage = stage;
        this.userId = userId;
    }

    public void show() {
        Label welcomeLabel = new Label("Bienvenido a la sección de Usuario");

        // Botones para acceder a las diferentes funcionalidades
        Button compraCancionesButton = new Button("Compra de Canciones");
        compraCancionesButton.setOnAction(e -> new UserCancionScreen(stage, userId).show());

        Button compraAlbumesButton = new Button("Compra de Álbumes");
        compraAlbumesButton.setOnAction(e -> new UserAlbumScreen(stage, userId).show());

        Button historialComprasButton = new Button("Historial de Compras");
        historialComprasButton.setOnAction(e -> new UserHistorialScreen(stage, userId).show());

        Button datosPersonalesButton = new Button("Datos Personales");
        datosPersonalesButton.setOnAction(e -> new UserDatosScreen(stage, userId).show());

        // Botón de cerrar sesión
        Button logoutButton = new Button("Cerrar Sesión");
        logoutButton.setOnAction(e -> {
            // Cambiar la escena a la pantalla de inicio de sesión
            // CORRECCIÓN: pasamos el mismo 'stage' al constructor de LoginScreen
            Scene loginScene = new LoginScreen(stage).getLoginScene();
            stage.setScene(loginScene);
        });

        // Layout vertical
        VBox vbox = new VBox(15,
                welcomeLabel,
                compraCancionesButton,
                compraAlbumesButton,
                historialComprasButton,
                datosPersonalesButton,
                logoutButton
        );
        vbox.setStyle("-fx-padding: 20; -fx-alignment: center;");

        // Creamos la escena y la mostramos
        Scene scene = new Scene(vbox, 500, 400);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        stage.setScene(scene);
        stage.setTitle("Usuario - Menú Principal");
        stage.show();
    }
}
