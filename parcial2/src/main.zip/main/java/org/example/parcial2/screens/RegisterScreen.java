package org.example.parcial2.screens;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import org.example.parcial2.utils.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterScreen {
    private final Stage stage;

    public RegisterScreen(Stage stage) {
        this.stage = stage;
    }

    public Scene getRegisterScene() {
        Label title = new Label("Registro de Usuario");
        title.setStyle("-fx-font-size: 24px; -fx-text-fill: white;");

        TextField nameField = new TextField();
        nameField.setPromptText("Nombre completo");
        nameField.setMaxWidth(250);

        TextField phoneField = new TextField();
        phoneField.setPromptText("Teléfono");
        phoneField.setMaxWidth(250);

        TextField emailField = new TextField();
        emailField.setPromptText("Correo electrónico");
        emailField.setMaxWidth(250);

        TextField userField = new TextField();
        userField.setPromptText("Usuario (username)");
        userField.setMaxWidth(250);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Contraseña");
        passwordField.setMaxWidth(250);

        ChoiceBox<String> roleChoice = new ChoiceBox<>();
        roleChoice.getItems().addAll("user", "artist");
        roleChoice.setValue("user");

        Button registerButton = new Button("Registrar");
        registerButton.setStyle("-fx-background-color: #1DB954; -fx-text-fill: white; -fx-font-weight: bold;");

        Hyperlink backToLogin = new Hyperlink("Volver al login");
        backToLogin.setOnAction(e -> {
            // Regresar al login
            LoginScreen loginScreen = new LoginScreen(stage);
            stage.setScene(loginScreen.getLoginScene());
        });

        VBox formBox = new VBox(10,
                title,
                nameField,
                phoneField,
                emailField,
                userField,
                passwordField,
                roleChoice,
                registerButton,
                backToLogin
        );
        formBox.setAlignment(Pos.CENTER);
        formBox.setPadding(new Insets(20));
        formBox.setStyle("-fx-background-color: #121212;");

        registerButton.setOnAction(e -> {
            String nombre   = nameField.getText().trim();
            String telUser  = phoneField.getText().trim();
            String email    = emailField.getText().trim();
            String username = userField.getText().trim();
            String pass     = passwordField.getText().trim();
            String role     = roleChoice.getValue();

            if (nombre.isEmpty() || telUser.isEmpty() || email.isEmpty() ||
                    username.isEmpty() || pass.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Por favor completa todos los campos.");
                return;
            }

            // Validar si el username ya existe
            if (Database.getInstance().authenticateUser(username, pass)) {
                // Nota: authenticateUser compara también password, así que convendría
                // crear un método extra para verificar solo existencia de username.
                // Para un truco rápido, podemos hacer:
                if (Database.getInstance().getUserId(username) != -1) {
                    showAlert(Alert.AlertType.WARNING, "El nombre de usuario ya existe.");
                    return;
                }
            }

            // Insertamos el nuevo usuario en la base de datos
            String sql = "INSERT INTO Usuarios (nombre, telUser, emailUser, `User`, password, role) VALUES (?, ?, ?, ?, ?, ?)";
            try (Connection conn = Database.getInstance().getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, nombre);
                stmt.setString(2, telUser);
                stmt.setString(3, email);
                stmt.setString(4, username);
                stmt.setString(5, pass);
                stmt.setString(6, role);
                stmt.executeUpdate();

                showAlert(Alert.AlertType.INFORMATION, "Registro exitoso. Ya puedes iniciar sesión.");
                // Regresar a login
                LoginScreen loginScreen = new LoginScreen(stage);
                stage.setScene(loginScreen.getLoginScene());
            } catch (SQLException ex) {
                ex.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Error al registrar. Revisa la consola.");
            }
        });

        return new Scene(formBox, 450, 400);
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message, ButtonType.OK);
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
