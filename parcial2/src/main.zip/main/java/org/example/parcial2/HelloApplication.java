package org.example.parcial2;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.example.parcial2.screens.LoginScreen;

public class HelloApplication extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Crear una instancia de LoginScreen (con Stage) y obtener la escena de login
        LoginScreen loginScreen = new LoginScreen(primaryStage);
        Scene loginScene = loginScreen.getLoginScene();  // <-- ahora no recibe parámetros

        // Si tienes un archivo de estilos Logina.css en resources, lo agregas así:
        loginScene.getStylesheets().add(getClass().getResource("/Logina.css").toExternalForm());

        // Configurar la escena en el stage principal
        primaryStage.setScene(loginScene);
        primaryStage.setTitle("Login");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
