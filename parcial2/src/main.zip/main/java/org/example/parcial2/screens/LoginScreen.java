package org.example.parcial2.screens;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.parcial2.screens.admi.AdminScreen;
import org.example.parcial2.screens.users.UserScreen;
import org.example.parcial2.utils.Database;

public class LoginScreen {
    private final Stage stage;

    public LoginScreen(Stage stage) {
        this.stage = stage;
    }

    public Scene getLoginScene() {
        // Título principal
        Label title = new Label("Login");
        title.setStyle("-fx-font-size: 24px; -fx-text-fill: white;");

        // Campo de usuario
        TextField usernameField = new TextField();
        usernameField.setPromptText("Usuario");
        usernameField.setMaxWidth(250);

        // Campo de contraseña
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Contraseña");
        passwordField.setMaxWidth(250);

        // Botón de login
        Button loginButton = new Button("Iniciar sesión");
        loginButton.setStyle("-fx-background-color: #1DB954; -fx-text-fill: white; -fx-font-weight: bold;");
        loginButton.setDefaultButton(true);

        // Link a registro
        Hyperlink registerLink = new Hyperlink("¿No tienes cuenta? Regístrate en Spotify");
        registerLink.setOnAction(e -> {
            RegisterScreen registerScreen = new RegisterScreen(stage);
            stage.setScene(registerScreen.getRegisterScene());
        });

        // Layout vertical
        VBox formBox = new VBox(10, title, usernameField, passwordField, loginButton, registerLink);
        formBox.setAlignment(Pos.CENTER);
        formBox.setPadding(new Insets(20));
        formBox.setStyle("-fx-background-color: #121212;");

        // Acción al hacer clic en login
        loginButton.setOnAction(e -> {
            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();

            if (username.isEmpty() || password.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Por favor ingresa usuario y contraseña.");
                return;
            }

            boolean ok = Database.getInstance().authenticateUser(username, password);
            if (ok) {
                int idUser = Database.getInstance().getUserId(username);
                String role = Database.getInstance().getUserRole(username);

                if ("admin".equalsIgnoreCase(role)) {
                    // Usamos el constructor existente: AdminScreen(Stage)
                    AdminScreen adminScreen = new AdminScreen(stage);
                    adminScreen.show();
                } else {
                    UserScreen userScreen = new UserScreen(stage, idUser);
                    userScreen.show();
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Usuario o contraseña incorrectos");
            }
        });

        return new Scene(formBox, 400, 300);
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type, message, ButtonType.OK);
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
