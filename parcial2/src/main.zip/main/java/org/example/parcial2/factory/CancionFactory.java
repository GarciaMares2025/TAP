package org.example.parcial2.factory;

import org.example.parcial2.models.Cancion;

import java.sql.Time;

public class CancionFactory {
    public static Cancion crearCancion(
            String titulo,
            Time duracion,
            int idGenero
    ) {
        // idCancion lo genera la BD, así que va como 0
        return new Cancion(0, titulo, duracion, idGenero);
    }
}
