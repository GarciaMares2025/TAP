package org.example.parcial2.repository;

import java.util.List;

public interface Repository<T> {
    T buscarPorId(int id);
    List<T> buscarTodos();
    void guardar(T entidad);
    void actualizar(T entidad);
    void eliminar(int id);
}
