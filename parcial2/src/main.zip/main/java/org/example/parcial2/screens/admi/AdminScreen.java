package org.example.parcial2.screens.admi;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.example.parcial2.screens.LoginScreen;

public class AdminScreen {

    private final Stage stage;

    public AdminScreen(Stage stage) {
        this.stage = stage;
    }

    public void show() {
        Label welcomeLabel = new Label("Bienvenido administrador");

        // Ejemplo de botón "Usuarios"
        Button usuariosButton = new Button("Gestionar Usuarios");
        usuariosButton.setOnAction(e -> {
            // Aquí iría la lógica para abrir la pantalla de usuarios
            // Por ejemplo: new AdminUsuariosScreen(stage).show();
        });

        // Otros botones de la pantalla de Admin...
        Button artistasButton = new Button("Gestionar Artistas");
        // artistasButton.setOnAction( ... );

        Button generosButton = new Button("Gestionar Géneros");
        // generosButton.setOnAction( ... );

        Button totalVentasButton = new Button("Ver Total de Ventas");
        // totalVentasButton.setOnAction( ... );

        // Botón de cerrar sesión
        Button logoutButton = new Button("Cerrar Sesión");
        logoutButton.setOnAction(e -> {
            // Cambiamos la escena a la pantalla de inicio de sesión (Login)
            LoginScreen loginScreen = new LoginScreen(stage);
            Scene loginScene = loginScreen.getLoginScene();
            stage.setScene(loginScene);
            stage.setTitle("Login"); // Opcional: volver a titular la ventana
        });

        // Layout vertical con todos los botones
        VBox vbox = new VBox(10,
                welcomeLabel,
                usuariosButton,
                artistasButton,
                generosButton,
                totalVentasButton,
                logoutButton
        );
        vbox.setStyle("-fx-padding: 20; -fx-alignment: center;");

        // Crear la escena y mostrarla
        Scene scene = new Scene(vbox, 400, 400);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        stage.setScene(scene);
        stage.setTitle("Ventana de Administrador");
        stage.show();
    }
}
